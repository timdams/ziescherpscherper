# Een eigen cursus opzetten met Quarto + GitHub Pages

Dit mapje bevat alles wat je nodig hebt om exact dezelfde opzet te krijgen als
[https://timdams.github.io/ziescherpscherper/](https://timdams.github.io/ziescherpscherper/): een handboek dat automatisch een website **en** een pdf
wordt, plus lesslides, allemaal vanuit één GitHub-repo.

Je vindt hier drie bestanden:

| Bestand | Wat doe je ermee? |
|---|---|
| **LEESMIJ.md** (dit bestand) | Lees dit eerst. Bevat de stappen die jij zelf moet doen (installeren, klikken op GitHub). |
| **SETUP-PROMPT.md** | De prompt die je aan Claude Code (of Copilot) geeft. Die maakt alle bestanden aan. |
| **CLAUDE-template.md** | Het "geheugen" van je repo. Belandt uiteindelijk als `CLAUDE.md` in je project. |

---

## Wat krijg je op het einde?

```
https://JOUWNAAM.github.io/JOUWREPO/                  → het handboek (website)
https://JOUWNAAM.github.io/JOUWREPO/Jouw-Titel.pdf    → hetzelfde boek als pdf
https://JOUWNAAM.github.io/JOUWREPO/slides/           → de lesslides (html + pdf)
```

Alles wordt automatisch opnieuw gebouwd zodra je iets naar GitHub pusht. Jij schrijft dus enkel
tekst in Markdown, de rest gebeurt vanzelf.

---

## Stap 0: installeren (eenmalig, ~15 minuten)

Installeer in deze volgorde. Herstart VS Code helemaal op het einde.

1. **Quarto** : [quarto.org/docs/get-started](https://quarto.org/docs/get-started/)
   Windows-installer, gewoon doorklikken. Je hebt **geen** LaTeX nodig: de pdf wordt gemaakt met
   Typst, en dat zit al in Quarto ingebakken.
2. **Visual Studio Code** : [code.visualstudio.com](https://code.visualstudio.com/)
3. **De Quarto-extensie in VS Code**: klik links op het blokjes-icoon (Extensions), zoek `Quarto`,
   installeer die van *Posit*. Die geeft je een Preview-knop en syntax highlighting.
4. **Git** : [git-scm.com/download/win](https://git-scm.com/download/win). Alle standaardopties zijn goed.
5. Een **GitHub-account** op [github.com](https://github.com), als je er nog geen hebt.
6. Optioneel, enkel als je de slide-pdf's ook lokaal wil kunnen maken: **Node.js**
   ([nodejs.org](https://nodejs.org)). Op GitHub gebeurt dat sowieso automatisch, dus je kan dit
   gerust overslaan.

Controleer achteraf in een terminal (in VS Code: `Terminal > New Terminal`) of alles werkt:

```powershell
quarto --version
git --version
```

Krijg je twee versienummers te zien, dan zit je goed.

---

## Stap 1: de repo aanmaken op GitHub

1. Ga naar [github.com/new](https://github.com/new).
2. **Repository name**: kies iets zonder spaties of hoofdletters, bv. `mijn-cursus`.
   Die naam komt in je website-adres terecht, dus kies met zorg.
3. Zet ze op **Public**.
   > Belangrijk: GitHub Pages werkt enkel gratis bij een publieke repo. Wil je ze privé houden,
   > dan heb je een betalend GitHub-plan nodig.
4. Vink **Add a README file** aan.
5. Klik **Create repository**.

## Stap 2: de repo op je pc zetten

Op de pagina van je nieuwe repo klik je op de groene knop **Code** en kopieer je de HTTPS-url.
Open dan VS Code, druk `Ctrl+Shift+P`, typ `Git: Clone`, plak de url en kies een map
(bijvoorbeeld `Documenten\cursussen`). VS Code vraagt achteraf of je de map wil openen: ja.

De eerste keer zal Git je vragen om in te loggen bij GitHub. Doe dat via de browser-knop,
dat is het makkelijkst.

## Stap 3: laat Claude Code de structuur bouwen

Open in VS Code een terminal in die map en start Claude Code. Open dan `SETUP-PROMPT.md`,
vul bovenaan de vier gegevens in (titel, auteur, GitHub-gebruikersnaam, repo-naam) en plak
de volledige inhoud in de chat.

Claude maakt dan alle mappen en bestanden aan, installeert de Quarto-extensies en doet een
eerste testrender. Duurt een paar minuten.

Werk je liever zonder AI-assistent? Geen probleem: in `SETUP-PROMPT.md` staat de volledige inhoud
van elk bestand uitgeschreven. Je kan ze ook gewoon zelf één voor één aanmaken.

## Stap 4: GitHub Pages aanzetten (dit moet je zelf doen)

Dit is de stap die het vaakst vergeten wordt, en geen enkele AI kan ze voor je doen: het is
puur klikwerk op de GitHub-website.

1. Ga naar je repo op github.com.
2. Klik bovenaan op **Settings**.
3. Klik links in het menu op **Pages**.
4. Bij *Build and deployment* zet je **Source** op **GitHub Actions**.
   (Dus **niet** op "Deploy from a branch".)

Meer moet je daar niet doen. Er is geen knop om op te slaan.

## Stap 5: alles online zetten

Terug in VS Code, in de terminal:

```powershell
git add .
git commit -m "Eerste opzet van de cursus"
git push
```

Ga nu naar je repo op github.com en klik bovenaan op **Actions**. Je ziet daar je build lopen:
een oranje bolletje betekent bezig, groen vinkje betekent klaar, rood kruisje betekent stuk.
De eerste build duurt een minuut of drie.

Bij een groen vinkje staat je site live op:

```
https://JOUWNAAM.github.io/JOUWREPO/
```

---

## Zo werk je van dag tot dag

Schrijven en lokaal bekijken:

```powershell
quarto preview .          # boek, opent in je browser en ververst terwijl je typt
quarto preview slides/    # slides
```

Druk `Ctrl+C` in de terminal om de preview te stoppen.

Klaar met schrijven? Dan publiceren in drie commando's:

```powershell
git add .
git commit -m "Hoofdstuk 3 afgewerkt"
git push
```

Enkele minuten later staat het online. Je hoeft nooit iets handmatig te uploaden.

> **Tip**: je kan dit ook volledig via de knopjes doen. In VS Code klik je links op het
> vertakkings-icoon (Source Control), typ je een berichtje bovenaan, klik je **Commit** en
> daarna **Sync Changes**. Exact hetzelfde resultaat.

---

## Als er iets misloopt

| Symptoom | Wat is er aan de hand? |
|---|---|
| Actions toont een **rood kruisje** | Klik op de mislukte run, dan op de rode stap. De laatste regels tonen meestal welk bestand of welke regel het probleem is. Vaak: een tikfout in `_quarto.yml` of een hoofdstuk dat in `_quarto.yml` staat maar niet bestaat. |
| Site toont **404** | Staat *Settings > Pages > Source* wel op **GitHub Actions**? En is de repo **Public**? |
| Site is leeg of ongestyled | Vergeet niet dat je site in een **submap** draait (`/jouwrepo/`). Gebruik nooit links die met een `/` beginnen. Schrijf `assets/foto.png`, niet `/assets/foto.png`. |
| **Afbeeldingen ontbreken** online, lokaal wel zichtbaar | Bijna altijd een verschil in hoofdletters. Linux (waar GitHub bouwt) ziet `Foto.PNG` en `foto.png` als twee verschillende bestanden, Windows niet. Hou alles consequent in kleine letters. |
| Quarto klaagt over een **extension** | De map `_extensions/` moet mee in Git. Staat ze niet in je repo, dan faalt de build. Check dat ze niet per ongeluk in `.gitignore` staat. |
| De **pdf** faalt, de website lukt wel | Dan is het de Typst-stap. Zoek in het log naar de foutmelding: meestal een afbeelding die niet gevonden wordt, of een te brede tabel. Je kan `typst:` tijdelijk uit `_quarto.yml` halen om weer online te geraken. |
| Slide-**pdf's** ontbreken | Die worden pas gemaakt na de html-render van de slides. Draaide de decktape-stap? Bij een gloednieuwe repo zonder slides is dat normaal. |
| `git push` wordt **geweigerd** | Iemand (of jijzelf via de website) heeft intussen iets gewijzigd. Doe eerst `git pull`, dan opnieuw `git push`. |

Blijf je vastzitten: kopieer de laatste ~20 regels van het foutlog en plak ze in Claude Code met
de vraag "wat loopt hier mis?". Dat werkt meestal meteen.
