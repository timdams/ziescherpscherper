# Setup-prompt: Quarto-cursus met website, pdf en slides

**Hoe gebruik je dit bestand?**
Vul hieronder de gegevens in, en plak daarna dit **volledige bestand** in Claude Code (of een
andere AI-assistent) terwijl je in de map van je lege repo staat.

Wil je het liever handmatig doen: verderop staat de volledige inhoud van elk bestand
uitgeschreven. Je kan ze gewoon één voor één zelf aanmaken.

---

## Vul dit eerst in

```
TITEL          = "De titel van mijn cursus"
AUTEUR         = "Voornaam Achternaam"
GITHUB_USER    = mijngebruikersnaam
REPO           = mijn-cursus
VAK            = waar de cursus over gaat, in één zin
```

Overal waar hieronder `TITEL`, `AUTEUR`, `GITHUB_USER`, `REPO` of `VAK` staat, komt jouw waarde.

---

## Opdracht

Je zet in de huidige (lege) map een Quarto-project op dat drie dingen produceert vanuit één
GitHub-repo, automatisch gepubliceerd op GitHub Pages:

1. Een **handboek** als website (Quarto `book`, html-output).
2. Datzelfde handboek als **pdf**, via Typst (dus **niet** via LaTeX).
3. Een aparte **slides-website** met revealjs-presentaties, plus een pdf per presentatie.

De gebruiker heeft **weinig GitHub-ervaring**. Hou het daarom eenvoudig, leg in je antwoorden
kort uit wat je doet, en verzin niets bij: gebruik exact de bestanden hieronder, met de
ingevulde waarden.

### Werkwijze

Werk deze stappen in volgorde af en meld na elke stap kort wat er gelukt is.

**Stap 1: mappenstructuur**

```
.
├── _quarto.yml
├── _brand.yml
├── custom.scss
├── index.qmd
├── references.bib
├── .gitignore
├── CLAUDE.md
├── content/
│   ├── assets/
│   │   └── 1_start/            (leeg, hier komen de afbeeldingen)
│   └── 1_start/
│       ├── 1_inleiding.md
│       └── 2_tweede.md
├── slides/
│   ├── _quarto.yml
│   ├── _brand.yml
│   ├── slides.scss
│   ├── overzicht.qmd
│   └── h01_start.qmd
└── .github/
    └── workflows/
        └── publish.yml
```

**Stap 2: extensies installeren**

```bash
quarto add quarto-ext/lightbox --no-prompt
cd slides && quarto add grantmcdermott/quarto-revealjs-clean --no-prompt && cd ..
```

Lukt een van beide niet (geen netwerk, of de prompt blijft hangen), meld dat dan en pas het
bijhorende `_quarto.yml` aan: haal `lightbox: true` weg, of gebruik voor de slides
`theme: [default, slides.scss]` zonder de clean-scss. Alles blijft dan werken, enkel wat
soberder. Zoek geen alternatieve extensie.

**Stap 3: alle bestanden aanmaken** met exact de inhoud uit de sectie "Bestanden" hieronder.

**Stap 4: testrender**

```bash
quarto render .
quarto render slides/
```

Los eventuele fouten op. Controleer daarna dat deze bestanden bestaan:

- `build/index.html`
- `build/<TITEL-met-koppeltekens>.pdf`
- `build/slides/overzicht.html`
- `build/slides/h01_start.html`

Faalt enkel de Typst/pdf-stap: probeer ze op te lossen, maar sloop de html-render er niet voor.
Meld gewoon wat niet lukt.

**Stap 5: rapporteer** in het kort:

- wat er gerenderd is,
- welke twee bestanden de gebruiker moet aanpassen om een hoofdstuk toe te voegen,
- de herinnering dat *Settings > Pages > Source* op GitHub nog manueel op **GitHub Actions**
  moet worden gezet.

Doe **geen** `git commit` en **geen** `git push`. Dat doet de gebruiker zelf.

### Harde regels

- **Geen em-dashes** in de tekst die je schrijft. Gebruik een gewoon koppelteken, een dubbele
  punt of een nieuwe zin.
- Alle cursustekst is **Nederlands**, informeel, je-vorm.
- Gebruik **relatieve paden** voor afbeeldingen en links. Nooit iets dat met `/` begint: de site
  draait in een submap (`https://GITHUB_USER.github.io/REPO/`) en absolute paden breken daar.
- Bestandsnamen: **kleine letters**, geen spaties, geen accenten. GitHub bouwt op Linux en dat is
  hoofdlettergevoelig, Windows niet. Dit is veruit de vaakst voorkomende oorzaak van "lokaal
  werkt het wel, online niet".
- Elk hoofdstuk dat in `_quarto.yml` staat, **moet ook echt bestaan**, anders faalt de render.
- De map `_extensions/` moet **mee in Git**. Zet ze nooit in `.gitignore`.

---

# Bestanden

## `_quarto.yml` (hoofdmap)

Dit stuurt het hele boek aan. De lijst onder `chapters` is tegelijk de zijbalk van de website en
de inhoudstafel van de pdf: hier voeg je later elk nieuw hoofdstuk toe.

```yaml
project:
  type: book
  output-dir: build

lang: nl

book:
  title: "TITEL"
  author: "AUTEUR"
  site-url: https://GITHUB_USER.github.io/REPO/
  repo-url: https://github.com/GITHUB_USER/REPO
  sidebar:
    collapse-level: 1
  navbar:
    background: light
    pinned: true
    left:
      - text: "Handboek"
        href: index.qmd
      - text: "Slides"
        href: slides/overzicht.html
  chapters:
    - index.qmd
    - part: "H1: Van start"
      chapters:
        - content/1_start/1_inleiding.md
        - content/1_start/2_tweede.md

bibliography: references.bib

format:
  html:
    theme: [cosmo, brand, custom.scss]
    toc: true
    toc-title: "Op deze pagina"
    lightbox: true
    number-sections: false
    highlight-style: github
    code-copy: true
    grid:
      sidebar-width: 280px
      body-width: 900px
      margin-width: 200px
      gutter-width: 1.5rem
  typst:
    mainfont: "Arial"
    papersize: a4
    section-numbering: "1.1"
    margin:
      x: 2.5cm
      y: 3cm
```

Wat je hier moet weten:

- `output-dir: build` betekent dat álle output in `build/` belandt. Die map staat in
  `.gitignore` en hoort nooit in Git: GitHub maakt ze zelf opnieuw bij elke push.
- Twee items onder `format:` betekent twee outputs uit één render. Quarto zet normaal een
  downloadknop voor de pdf bij de zijbalk. Zie je die niet, link er dan zelf naar vanuit
  `index.qmd` met `[Download als pdf](TITEL-met-koppeltekens.pdf)`.
- `href: slides/overzicht.html` verwijst naar `.html`, niet naar `.qmd`. De slides zijn een
  **apart** Quarto-project: het boek kent die bronbestanden niet, enkel het eindresultaat.
- `lang: nl` vertaalt de knoppen en labels van Quarto naar het Nederlands.

## `_brand.yml` (hoofdmap)

Je huisstijlkleuren op één plek. Pas deze hex-codes aan naar de kleuren van je school of vak.

```yaml
color:
  palette:
    hoofdkleur: "#0B5FFF"
    hoofdkleur-donker: "#08409F"
    hoofdkleur-licht: "#E8F0FF"
    grijs: "#4D4D4D"
    offwhite: "#F8F9FA"
  foreground: grijs
  background: offwhite
  primary: hoofdkleur
  secondary: hoofdkleur-donker
```

## `custom.scss` (hoofdmap)

Kleine bijsturingen bovenop het `cosmo`-thema: iets groter lettertype en rustiger regelafstand.
Alles hierin is optioneel, je mag het gerust laten zoals het is.

```scss
/*-- scss:defaults --*/

$font-size-root: 17px;
$line-height-base: 1.7;
$headings-line-height: 1.25;
$headings-font-weight: 700;
$paragraph-margin-bottom: 1.15rem;

$body-bg: #fafaf7;
$body-color: #2b2b33;
$headings-color: #1a1a22;

$border-radius: 0.5rem;
$border-color: #e6e8eb;
$navbar-bg: #ffffff;

/*-- scss:rules --*/

// Codeblokken wat rustiger maken
div.sourceCode {
  border: 1px solid $border-color;
  border-radius: $border-radius;
}

// Tabellen niet over de rand laten lopen op smalle schermen
table {
  max-width: 100%;
}

// De syntax highlighter kleurt escape-tekens apart en markeert ze soms zelfs
// als fout. Ze horen gewoon bij de string, dus laten we ze met rust.
code span.sc,
code span.er {
  color: inherit !important;
  text-decoration: none !important;
}
```

## `index.qmd` (hoofdmap)

De voorpagina van je boek. `{.unnumbered}` zorgt dat ze geen hoofdstuknummer krijgt.

````markdown
# Voorwoord {.unnumbered}

**TITEL** is een cursus over VAK, geschreven door AUTEUR.

Deze website is het volledige handboek. Je kan het ook
[als pdf downloaden](TITEL-met-koppeltekens.pdf), en de
[lesslides](slides/overzicht.html) staan er apart bij.

## Hoe gebruik je dit boek?

Elk hoofdstuk bouwt verder op het vorige. Lees ze dus best in volgorde.

## Fouten gevonden?

Open een [issue](https://github.com/GITHUB_USER/REPO/issues) of laat het me weten.
````

## `references.bib` (hoofdmap)

Bibliografie. Mag bijna leeg blijven, maar het bestand moet bestaan omdat `_quarto.yml` ernaar
verwijst.

```bibtex
@book{voorbeeld2024,
  title     = {Een voorbeeldboek},
  author    = {Auteur, Een},
  year      = {2024},
  publisher = {Uitgeverij}
}
```

## `content/1_start/1_inleiding.md`

Een voorbeeldhoofdstuk dat meteen de belangrijkste Quarto-trucs toont.

````markdown
# Inleiding

Welkom in het eerste hoofdstuk. Dit is gewone Markdown: **vet**, *cursief*, en lijstjes met
een streepje.

## Een codevoorbeeld

Zet de taal na de drie backticks, dan krijg je kleuren en een kopieerknop.

```csharp
Console.WriteLine("Hallo wereld");
```

## Een callout

Quarto heeft ingebouwde kaderblokken. De vier types die je het meest zal gebruiken:
`note`, `tip`, `important` en `warning`.

:::{.callout-tip}
## Zo maak je een tip
Zet de tekst tussen drie dubbele punten, en sluit af met drie dubbele punten.
:::

:::{.callout-important}
Dit is een belangrijke waarschuwing.
:::

## Een afbeelding

Zet je afbeeldingen in `content/assets/1_start/` en verwijs er relatief naar:

![Een onderschrift bij de figuur](../assets/1_start/voorbeeld.png)

Dankzij de lightbox-extensie kan de lezer erop klikken om ze groot te zien.
````

## `content/1_start/2_tweede.md`

````markdown
# Het tweede hoofdstuk

Voeg zo veel hoofdstukken toe als je wil. Twee dingen per nieuw hoofdstuk:

1. maak het bestand aan onder `content/`,
2. zet het pad in `_quarto.yml` onder `chapters:`.

Vergeet je stap 2, dan verschijnt het hoofdstuk nergens. Zet je in stap 2 een bestand dat niet
bestaat, dan faalt de hele render.
````

## `slides/_quarto.yml`

De slides zijn een **apart Quarto-project** met een eigen configuratie. Ze renderen naar
`../build/slides`, dus binnen dezelfde `build/`-map als het boek. Zo komt alles op één site terecht.

```yaml
project:
  type: website
  output-dir: ../build/slides
  render:
    - "*.qmd"

website:
  title: "TITEL"
  navbar:
    background: light
    pinned: true
    left:
      - text: "Handboek"
        href: ../index.html
      - text: "Slides"
        href: overzicht.qmd

format:
  revealjs:
    theme: [default, _extensions/grantmcdermott/clean/clean.scss, slides.scss]
    lang: nl
    slide-number: true
    transition: slide
```

## `slides/_brand.yml`

Exact dezelfde inhoud als de `_brand.yml` in de hoofdmap. Elk Quarto-project heeft zijn eigen
kopie nodig: een subproject kijkt niet naar de map erboven. Pas je later je kleuren aan, doe het
dan op beide plaatsen.

## `slides/slides.scss`

```scss
/*-- scss:rules --*/

// Lange codeblokken op een slide scrollbaar houden
.reveal pre code {
  max-height: 500px;
}

code span.sc,
code span.er {
  color: inherit !important;
  text-decoration: none !important;
}
```

## `slides/overzicht.qmd`

De landingspagina van je slides. Dit is bewust een gewone html-pagina en géén presentatie: het
is het overzicht met links naar elke set slides en de bijhorende pdf. Bij elke nieuwe presentatie
voeg je hier een regel toe.

````markdown
---
title: "Slides"
format:
  html:
    theme: [cosmo, brand, ../custom.scss]
    lang: nl
    toc: false
---

Hieronder vind je de lesslides. Elke presentatie opent in een nieuw tabblad, of je downloadt ze
als pdf.

## Beschikbare presentaties

| Hoofdstuk | Presentatie | PDF |
|-----------|-------------|-----|
| ✅ H1: Van start | [Bekijk slides](h01_start.html){target="_blank"} | [Download PDF](h01_start.pdf) |

**Legende:**

* ✅: beschikbaar
* 🕒: in ontwikkeling, nog geen leerstof
* ❌: nog niet beschikbaar
````

## `slides/h01_start.qmd`

Eén presentatie. Elke `##` begint een nieuwe slide, en `---` op een eigen regel ook.
`embed-resources: true` propt alles in één html-bestand, zodat je een slide los kan doorsturen
of offline kan tonen.

````markdown
---
title: "Van start"
subtitle: "TITEL - Hoofdstuk 1"
author: "AUTEUR"
format:
  revealjs:
    theme: [default, _extensions/grantmcdermott/clean/clean.scss]
    lang: nl
    slide-number: true
    transition: slide
    embed-resources: true
---

## Wat leer je in dit hoofdstuk?

Na dit hoofdstuk kan je:

* het eerste concept uitleggen
* het tweede concept toepassen

---

## Een slide met code

```csharp
Console.WriteLine("Hallo wereld");
```

## Een slide met twee kolommen

:::: {.columns}

::: {.column width="50%"}
Links wat tekst.
:::

::: {.column width="50%"}
Rechts nog wat tekst.
:::

::::

## Tot slot

Bedankt voor je aandacht.
````

## `.github/workflows/publish.yml`

Dit is het recept dat GitHub uitvoert bij elke push naar `main`: het boek renderen, de slides
renderen, de slides naar pdf omzetten, en alles naar GitHub Pages publiceren.

```yaml
name: Build and Publish

on:
  push:
    branches:
      - main
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: true

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Quarto
        uses: quarto-dev/quarto-actions/setup@v2

      - name: Render boek (html + pdf)
        run: quarto render .

      - name: Render slides
        run: quarto render slides/

      - name: Slides omzetten naar pdf
        run: |
          npm install -g decktape
          for f in build/slides/*.html; do
            name=$(basename "$f" .html)
            [ "$name" = "overzicht" ] && continue
            [ "$name" = "index" ] && continue
            echo "Converteren van $name..."
            decktape reveal "file://$(pwd)/build/slides/${name}.html" \
              "build/slides/${name}.pdf" \
              --size 1920x1080 --chrome-arg=--no-sandbox || true
          done

      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: build/

  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

Wat je hier moet weten:

- **De volgorde is belangrijk.** Eerst `quarto render .` (het boek), pas daarna de slides. Het
  boek beheert de `build/`-map en zou output van een subproject kunnen opruimen als het als
  tweede draait.
- `decktape` maakt van elke revealjs-slide een pdf. De `|| true` op het einde zorgt dat één
  mislukte slide je hele publicatie niet blokkeert.
- `workflow_dispatch` geeft je in de Actions-tab een knop om handmatig opnieuw te bouwen, zonder
  iets te moeten pushen.
- `concurrency` voorkomt dat twee builds tegelijk naar Pages proberen te schrijven.

## `.gitignore` (hoofdmap)

```
# Quarto
.quarto/
*_cache/
*_files/
**/*.quarto_ipynb
/build/
site_libs/
node_modules/

# Quarto rendert bij een losse render ook html náást de bron.
# Niets daarvan hoort in de repo: echte output gaat naar build/.
*.html

# Windows
Thumbs.db
Desktop.ini
```

Let op: `_extensions/` staat hier bewust **niet** in. Die map moet wél mee naar GitHub, anders
vindt de build je slidethema en de lightbox niet.

## `CLAUDE.md` (hoofdmap)

Neem hiervoor de inhoud van `CLAUDE-template.md` over, met de placeholders ingevuld. Dat bestand
is het geheugen van je repo: elke AI-assistent die je later in deze map opent, leest het
automatisch en weet dan meteen hoe je project in elkaar zit en in welke stijl je schrijft.

---

# Later uitbreiden

Onderstaande zaken heb je niet nodig om te starten. Vraag ze pas als je ze echt wil.

## Een derde deelsite (bijvoorbeeld oefeningen)

Zelfde recept als de slides: een map `oefeningen/` met een eigen `_quarto.yml`
(`type: website`, `output-dir: ../build/oefeningen`), een eigen `_brand.yml`, en één extra
regel in de workflow:

```yaml
      - name: Render oefeningen
        run: quarto render oefeningen/
```

Zet er ook een link naar in de navbar van elk project. Onthou: tussen projecten link je altijd
naar `.html`, binnen een project naar `.qmd` of `.md`.

## Slide-pdf's sneller maken

Bij tien of meer presentaties wordt het omzetten naar pdf traag, want elke build zet álles
opnieuw om. Je kan de pdf's laten cachen en enkel de gewijzigde slides opnieuw converteren.
Een uitgewerkt voorbeeld staat in
[timdams/ziescherpscherper](https://github.com/timdams/ziescherpscherper/blob/main/.github/workflows/publish.yml).

## Een eigen domeinnaam

Kan via *Settings > Pages > Custom domain*. Je hebt dan wel toegang tot de DNS-instellingen van
dat domein nodig.
