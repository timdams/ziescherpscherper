# CLAUDE.md

> Dit bestand komt als `CLAUDE.md` in de hoofdmap van je repo. Elke AI-assistent die je in
> deze map opent, leest het automatisch mee. Vervang de `{{...}}`-stukken door jouw gegevens
> en schrap wat niet klopt. Hou het kort en feitelijk: hoe langer dit bestand, hoe minder
> aandacht elke regel krijgt.

## Wat is dit project?

**{{TITEL}}** is een cursus over {{VAK}}, geschreven door {{AUTEUR}} ({{SCHOOL}}) en
gepubliceerd op <https://{{GITHUB_USER}}.github.io/{{REPO}}/>.

Het project bouwt twee Quarto-outputs die samen op één GitHub Pages-site terechtkomen:

| Output | Bron | Type | Doel |
|---|---|---|---|
| Handboek | hoofdmap + `content/` | Quarto **book** (html + Typst/pdf) | De cursus zelf |
| Slides | `slides/` | Quarto website (revealjs) | Lesslides, met overzichtspagina |

## Repo-layout

```
{{REPO}}/
├── _quarto.yml              # config van het boek (type: book, output-dir: build/)
├── _brand.yml               # huisstijlkleuren, gebruikt via `theme: brand`
├── custom.scss              # html-thema overrides
├── index.qmd                # voorwoord / voorpagina
├── references.bib           # bibliografie
├── _extensions/             # Quarto-extensies (lightbox). MOET in Git blijven.
├── content/                 # alle hoofdstukken
│   ├── assets/              # afbeeldingen, per hoofdstuk in een submap
│   └── 1_start/ ...
├── slides/                  # eigen Quarto-project (sub-_quarto.yml, eigen _brand.yml)
├── build/                   # output, gitignored
└── .github/workflows/publish.yml
```

## Build- en publish-flow

Lokaal:

```bash
quarto preview .          # boek, live in de browser
quarto preview slides/    # slides
quarto render .           # boek definitief renderen naar build/ (html + pdf)
quarto render slides/     # slides naar build/slides/
```

**Altijd eerst het boek renderen, dan de subprojecten.** Het boek beheert `build/` en kan
output van een subproject opruimen als het als tweede draait.

CI: [.github/workflows/publish.yml](.github/workflows/publish.yml) doet bij elke push naar
`main` precies hetzelfde, zet daarna elke revealjs-slide met decktape om naar pdf, en publiceert
`build/` naar GitHub Pages.

## Een hoofdstuk toevoegen

Twee dingen, altijd allebei:

1. Maak het bestand aan onder `content/`, bv. `content/3_iets/1_intro.md`.
2. Zet dat pad in `_quarto.yml` onder `chapters:`.

Een bestand dat wel in `_quarto.yml` staat maar niet bestaat, laat de hele render falen.

## Een presentatie toevoegen

1. Maak `slides/hNN_naam.qmd` aan (kopieer de YAML-header van een bestaande slide).
2. Voeg een regel toe aan de tabel in `slides/overzicht.qmd`.

De pdf wordt automatisch gemaakt door de CI, daar hoef je niets voor te doen.

## Schrijfstijl en conventies

- Taal: **Nederlands**, informeel, je-vorm.
- **Geen em-dashes.** Niet in de cursustekst, niet in chat. Gebruik een gewoon koppelteken, een
  dubbele punt, haakjes, of gewoon een nieuwe zin.
- Bestanden zijn `.md` of `.qmd`. In Quarto gedragen die zich nagenoeg gelijk.
- Kaderblokken via Quarto-syntax: `:::{.callout-important}` ... `:::`.
- Afbeeldingen komen in `content/assets/<hoofdstukmap>/` en worden **relatief** aangesproken.
  Nooit een pad dat met `/` begint: de site draait in een submap.
- Bestandsnamen in **kleine letters**, zonder spaties of accenten. GitHub bouwt op Linux
  (hoofdlettergevoelig), Windows niet.

<!-- Vul hier je eigen vakterminologie aan, bijvoorbeeld:
- Gebruik consequent "{{term}}" en niet "{{synoniem}}".
- Concept X wordt pas in hoofdstuk N geïntroduceerd, gebruik het niet eerder.
-->

### Anti-AI-stijl

De tekst moet klinken alsof jij het uitlegt, niet als een chatbot die netjes afrondt. Vermijd:

- **Geen samenvattende slotzin** onder een kader of een vergelijking. Stop na het laatste
  codevoorbeeld of na de feitelijke uitleg.
- **Geen tel-formules** ("Drie talen, hetzelfde idee"). De lezer ziet de blokken zelf staan.
- **Geen symmetrische antithese** als afsluiter ("X kiest gemak, Y kiest zekerheid"). Die
  spiegelzinnen klinken als een quote-card.
- **Geen grootse rhetoriek** ("de ontwikkelaar van morgen"). Nuchter en praktisch.
- Test voor een slotzin: voegt hij een *feit* toe? Zo nee, schrappen. Een uitleg mag gerust
  droog en onafgewerkt eindigen.

## Niet aanraken zonder reden

- `_quarto.yml` (hoofdmap én `slides/`): de paden zijn handmatig onderhouden. Een mapnaam
  veranderen breekt de zijbalk.
- `_extensions/`: door `quarto add` geïnstalleerd, hoort in Git, wijzig er niets met de hand.
- `.quarto/`: build-cache, verschijnt soms als gewijzigd in `git status` maar is een artefact.
- `build/`: volledig gegenereerd, staat in `.gitignore`.

## Wat een assistent hier niet moet doen

- Niet committen of pushen zonder dat er expliciet om gevraagd wordt.
- Geen hoofdstukken herschrijven "ter verbetering" als er enkel om een correctie gevraagd is.
- Geen nieuwe mappenstructuur voorstellen: paden staan op twee plaatsen en breken makkelijk.
